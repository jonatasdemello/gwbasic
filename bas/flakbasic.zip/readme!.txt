FLAK Explosion simulation!

Contact me at kburnik@twister.zrs.hr!

Flak Explosion v4.0 Simulation of an exploding Flak shell in MS-DOS QBASIC. 
This is version 4! Includes simple projectile motion physics simulation! 